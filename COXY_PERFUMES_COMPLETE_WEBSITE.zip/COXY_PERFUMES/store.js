(() => {
  const cfg = window.COXY_CONFIG || {};
  const grid = document.getElementById("productGrid");
  const message = document.getElementById("storeMessage");
  const search = document.getElementById("searchInput");
  document.getElementById("year").textContent = new Date().getFullYear();

  if (!window.supabase || !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
    message.textContent = "The store connection is not configured. Please check config.js.";
    return;
  }
  const db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);
  let products = [];

  function render(list) {
    grid.innerHTML = "";
    if (!list.length) {
      message.textContent = products.length ? "No perfumes match your search." : "No perfumes are listed yet. Please check back soon.";
      return;
    }
    message.textContent = "";
    list.forEach(p => {
      const card = document.createElement("article");
      card.className = "product-card";
      const image = document.createElement("div");
      image.className = "product-image";
      if (p.image_url) {
        const img = document.createElement("img");
        img.src = p.image_url; img.alt = p.name || "Perfume"; img.loading = "lazy";
        img.onerror = () => { image.textContent = "Image unavailable"; };
        image.appendChild(img);
      } else image.textContent = "COXY PERFUMES";
      const info = document.createElement("div"); info.className = "product-info";
      const title = document.createElement("h3"); title.textContent = p.name || "Perfume";
      const desc = document.createElement("p"); desc.textContent = p.description || "Discover this fragrance from COXY PERFUMES.";
      const row = document.createElement("div"); row.className = "price-row";
      const price = document.createElement("span"); price.className = "price"; price.textContent = `GH₵ ${Number(p.price).toFixed(2)}`;
      const order = document.createElement("a"); order.className = "small-order"; order.textContent = "Order on WhatsApp";
      const number = String(cfg.WHATSAPP_NUMBER || "").replace(/\D/g, "");
      const text = encodeURIComponent(`Hello COXY PERFUMES, I would like to order ${p.name} for GH₵ ${Number(p.price).toFixed(2)}.`);
      order.href = `https://wa.me/${number}?text=${text}`; order.target = "_blank"; order.rel = "noopener";
      row.append(price, order); info.append(title, desc, row); card.append(image, info); grid.appendChild(card);
    });
  }

  async function load() {
    message.textContent = "Loading perfumes...";
    const { data, error } = await db.from("products").select("id,name,price,description,image_url,available").eq("available", true).order("created_at", { ascending: false });
    if (error) { message.textContent = "Unable to load perfumes right now. Please check the Supabase connection and table access."; console.error(error); return; }
    products = data || []; render(products);
  }
  search.addEventListener("input", () => {
    const q = search.value.trim().toLowerCase();
    render(products.filter(p => `${p.name || ""} ${p.description || ""}`.toLowerCase().includes(q)));
  });
  load();
})();