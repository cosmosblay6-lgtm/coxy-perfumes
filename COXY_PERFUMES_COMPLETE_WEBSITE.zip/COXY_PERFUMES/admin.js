(() => {
  const cfg = window.COXY_CONFIG || {};
  const $ = id => document.getElementById(id);
  $("year").textContent = new Date().getFullYear();
  const loginPanel = $("loginPanel"), dashboard = $("dashboardPanel");
  const loginMessage = $("loginMessage"), adminMessage = $("adminMessage");
  if (!window.supabase || !cfg.SUPABASE_URL || !cfg.SUPABASE_ANON_KEY) {
    loginMessage.textContent = "The Supabase connection is not configured. Check config.js.";
    return;
  }
  const db = window.supabase.createClient(cfg.SUPABASE_URL, cfg.SUPABASE_ANON_KEY);

  function showSession(session) {
    loginPanel.hidden = !!session;
    dashboard.hidden = !session;
    if (session) loadProducts();
  }
  async function checkSession() {
    const { data } = await db.auth.getSession();
    showSession(data.session);
  }
  $("loginForm").addEventListener("submit", async e => {
    e.preventDefault(); loginMessage.textContent = "Signing in...";
    const { error } = await db.auth.signInWithPassword({ email: $("email").value.trim(), password: $("password").value });
    if (error) { loginMessage.textContent = error.message; return; }
    loginMessage.textContent = ""; await checkSession();
  });
  $("logoutButton").addEventListener("click", async () => {
    await db.auth.signOut(); showSession(null);
  });
  db.auth.onAuthStateChange((_event, session) => showSession(session));

  function resetForm() {
    $("productForm").reset(); $("productId").value = ""; $("productAvailable").checked = true;
    $("saveProductButton").textContent = "Add perfume"; $("cancelEditButton").hidden = true;
  }
  $("cancelEditButton").addEventListener("click", resetForm);

  $("productForm").addEventListener("submit", async e => {
    e.preventDefault(); adminMessage.textContent = "Saving perfume...";
    const id = $("productId").value;
    const product = {
      name: $("productName").value.trim(),
      price: Number($("productPrice").value),
      description: $("productDescription").value.trim(),
      image_url: $("productImage").value.trim() || null,
      available: $("productAvailable").checked
    };
    if (!product.name || !Number.isFinite(product.price) || product.price < 0) {
      adminMessage.textContent = "Enter a perfume name and a valid price."; return;
    }
    const result = id ? await db.from("products").update(product).eq("id", id) : await db.from("products").insert(product);
    if (result.error) { adminMessage.textContent = result.error.message; return; }
    adminMessage.textContent = id ? "Perfume updated." : "Perfume added.";
    resetForm(); await loadProducts();
  });

  async function loadProducts() {
    const list = $("adminProductList"); list.textContent = "Loading products...";
    const { data, error } = await db.from("products").select("id,name,price,description,image_url,available").order("created_at", { ascending: false });
    if (error) { list.textContent = error.message; return; }
    list.innerHTML = "";
    if (!data || !data.length) { list.textContent = "No products have been added yet."; return; }
    data.forEach(p => {
      const row = document.createElement("div"); row.className = "admin-product";
      const details = document.createElement("div");
      const name = document.createElement("strong"); name.textContent = p.name;
      const meta = document.createElement("small"); meta.textContent = `GH₵ ${Number(p.price).toFixed(2)} · ${p.available ? "Available" : "Hidden"}`;
      details.append(name, meta);
      const actions = document.createElement("div"); actions.className = "admin-actions";
      const edit = document.createElement("button"); edit.className = "button button-outline"; edit.type = "button"; edit.textContent = "Edit";
      edit.addEventListener("click", () => {
        $("productId").value = p.id; $("productName").value = p.name; $("productPrice").value = p.price;
        $("productDescription").value = p.description || ""; $("productImage").value = p.image_url || "";
        $("productAvailable").checked = !!p.available; $("saveProductButton").textContent = "Save changes";
        $("cancelEditButton").hidden = false; window.scrollTo({ top: 0, behavior: "smooth" });
      });
      const del = document.createElement("button"); del.className = "button button-outline"; del.type = "button"; del.textContent = "Delete";
      del.addEventListener("click", async () => {
        if (!confirm(`Delete "${p.name}"?`)) return;
        const { error: deleteError } = await db.from("products").delete().eq("id", p.id);
        adminMessage.textContent = deleteError ? deleteError.message : "Perfume deleted.";
        if (!deleteError) loadProducts();
      });
      actions.append(edit, del); row.append(details, actions); list.appendChild(row);
    });
  }
  checkSession();
})();