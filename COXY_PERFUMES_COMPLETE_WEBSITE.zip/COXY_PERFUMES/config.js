window.COXY_CONFIG = {
  SUPABASE_URL: "https://pcarpaipqrfcorfrnetp.supabase.co",
  SUPABASE_ANON_KEY: "sb_publishable_OWVr6yNoLz4e4OiuTGsdWg_CYZP0t5r",
  WHATSAPP_NUMBER: "233542704560"
};